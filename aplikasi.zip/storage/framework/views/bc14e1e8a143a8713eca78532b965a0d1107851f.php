<?php $__env->startSection('title', 'Staff Panel - Halaman Dashboard'); ?>


<?php $__env->startSection('content'); ?>
<div class="content-body">
    <div class="container-fluid">
        <div class="page-titles">
            <h4>Ubah CV</h4>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0)">Ubah CV</a></li>
            </ol>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Ubah CV</h4>
                    </div>
                    <div class="card-body">
                        <?php if(Session::has('status')): ?>
                            <?php if(Session::get('status') == 'berhasil'): ?>
                            <button class="btn btn-success mb-3"
                                style="width: 100%; border-radius: 10px; margin-bottom: 20px">Data Berhasil Diupdate</button>
                            <?php else: ?>
                            <button class="btn btn-danger mb-3"
                                style="width: 100%; border-radius: 10px; margin-bottom: 20px">Data Gagal Diupdate</button>
                            <?php endif; ?>
                        <?php endif; ?>
                        <div class="basic-form">
                            <form action="<?php echo e(route('update_curicullum_vitae')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id_curriculum_vitae" value="<?php echo e($data->id_curriculum_vitae); ?>">
                                <div class="form-group">
                                    <label>Nama Penyetor</label>
                                    <input value="<?php echo e($data->nama_penyetor); ?>" type="text" name="nama_penyetor" class="form-control input-rounded" placeholder="Apriyadi Aries">
                                </div>
                                <div class="form-group">
                                    <label>Tanggal Upload</label>
                                    <input value="<?php echo e($data->tanggal_upload); ?>" type="date" name="tanggal_upload" class="form-control input-rounded" placeholder="2021-06-15">
                                </div>
                                <div class="form-group">
                                    <label>Keterangan</label>
                                    <textarea value="<?php echo e($data->keterangan); ?>" type="text" name="keterangan" class="form-control" placeholder="..." name="" id="" cols="30"
                                        rows="10"><?php echo e($data->keterangan); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label>File CV</label>
                                    <input type="file" name="file_cv" class="form-control input-rounded" placeholder="...">
                                    <input type="hidden" name="file_cv_ada" value="<?php echo e($data->nama_file); ?>">
                                    <small>Lihat File <a href="<?php echo e(url('files/curicullum_vitae/')); ?>/<?php echo e($data->nama_file); ?>"><?php echo e($data->nama_file); ?></a></small>
                                </div>
                                <button type="submit" class="btn btn-primary">Proses</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--**********************************
    Content body end
***********************************-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PROJECT\Sistem Informasi Pengarsipan\resources\views/staff/edit/edit-curicullum-vitae.blade.php ENDPATH**/ ?>