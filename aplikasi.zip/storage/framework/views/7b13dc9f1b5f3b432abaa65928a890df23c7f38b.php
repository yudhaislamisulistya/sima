<?php $__env->startSection('title', 'Staff Panel - Halaman Dashboard'); ?>


<?php $__env->startSection('content'); ?>
<div class="content-body">
    <div class="container-fluid">
        <div class="page-titles">
            <h4>Daftar Arsip</h4>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0)">Daftar Arsip</a></li>
            </ol>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Daftar Arsip</h4>
                        <a href="<?php echo e(route('get_tambah_daftar_arsip')); ?>" class="btn btn-primary">Tambah Data</a>
                    </div>
                    <div class="card-body">
                        <?php if(Session::has('status')): ?>
                            <?php if(Session::get('status') == 'berhasil'): ?>
                            <button class="btn btn-success mb-3"
                                style="width: 100%; border-radius: 10px; margin-bottom: 20px">Data Berhasil Dihapus</button>
                            <?php else: ?>
                            <button class="btn btn-danger mb-3"
                                style="width: 100%; border-radius: 10px; margin-bottom: 20px">Data Gagal Dihapus</button>
                            <?php endif; ?>
                        <?php endif; ?>
                            <table id="example" class="display">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kode</th>
                                        <th>Tahun</th>
                                        <th>Jenis</th>
                                        <th>NIK</th>
                                        <th>Jenis Kelamin</th>
                                        <th>Tempat</th>
                                        <th>Informasi Lainnya</th>
                                        <th>Lampiran</th>
                                        <th>Keterangan</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($value->id_daftar_arsip); ?></td>
                                            <td><?php echo e($value->kode); ?></td>
                                            <td><?php echo e($value->tahun); ?></td>
                                            <td><?php echo e($value->jenis); ?></td>
                                            <td><?php echo e($value->nik); ?></td>
                                            <td><?php echo e($value->jenis_kelamin); ?></td>
                                            <td><?php echo e($value->tempat); ?></td>
                                            <td><?php echo e($value->informasi_lainnya); ?></td>
                                            <td><?php echo e($value->lampiran); ?></td>
                                            <td><?php echo e($value->keterangan); ?></td>
                                            <td>
                                                <a href="<?php echo e(url('files/lampiran')); ?>/<?php echo e($value->lampiran); ?>" class="btn btn-info">Lihat</a>
                                                <a href="<?php echo e(route('edit_daftar_arsip', ['id' => $value->id_daftar_arsip])); ?>" class="btn btn-primary">Edit</a>
                                                <a href="<?php echo e(route('delete_daftar_arsip', ['id' => $value->id_daftar_arsip, 'file_name' => $value->lampiran])); ?>" class="btn btn-danger">Hapus</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--**********************************
    Content body end
***********************************-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PROJECT\Sistem Informasi Pengarsipan\resources\views/staff/daftar-arsip.blade.php ENDPATH**/ ?>