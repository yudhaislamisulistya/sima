<?php $__env->startSection('title', 'Staff Panel - Halaman Dashboard'); ?>


<?php $__env->startSection('content'); ?>
<div class="content-body">
    <div class="container-fluid">
        <div class="page-titles">
            <h4>Jenis Dokumen</h4>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0)">Jenis Dokumen</a></li>
            </ol>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Jenis Dokumen</h4>
                        <a href="<?php echo e(route('get_tambah_jenis_dokumen')); ?>" class="btn btn-primary">Tambah Data</a>
                    </div>
                    <div class="card-body">
                        <?php if(Session::has('status')): ?>
                            <?php if(Session::get('status') == 'berhasil'): ?>
                            <button class="btn btn-success mb-3"
                                style="width: 100%; border-radius: 10px; margin-bottom: 20px">Data Berhasil Dihapus</button>
                            <?php else: ?>
                            <button class="btn btn-danger mb-3"
                                style="width: 100%; border-radius: 10px; margin-bottom: 20px">Data Gagal Dihapus</button>
                            <?php endif; ?>
                        <?php endif; ?>
                            <table id="example" class="display">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Kode</th>
                                        <th>Jenis Dokumen</th>
                                        <th>Keterangan</th>
                                        <th>Tanggal Buat</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($value->id_jenis_dokumen); ?></td>
                                            <td><?php echo e($value->kode); ?></td>
                                            <td><?php echo e($value->jenis_dokumen); ?></td>
                                            <td><?php echo e($value->keterangan); ?></td>
                                            <td><?php echo e($value->tanggal_buat); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('edit_jenis_dokumen', ['id' => $value->id_jenis_dokumen])); ?>" class="btn btn-primary">Edit</a>
                                                <a href="<?php echo e(route('delete_jenis_dokumen', ['id' => $value->id_jenis_dokumen])); ?>" class="btn btn-danger">Hapus</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--**********************************
    Content body end
***********************************-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PROJECT\Sistem Informasi Pengarsipan\resources\views/staff/jenis-dokumen.blade.php ENDPATH**/ ?>