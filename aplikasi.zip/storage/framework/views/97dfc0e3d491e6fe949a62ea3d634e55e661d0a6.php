<?php $__env->startSection('title', 'Staff Panel - Halaman Dashboard'); ?>


<?php $__env->startSection('content'); ?>
<div class="content-body">
    <div class="container-fluid">
        <div class="page-titles">
            <h4>Curricullum Vitae</h4>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0)">Curricullum Vitae</a></li>
            </ol>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Curricullum Vitae</h4>
                        <a href="<?php echo e(route('get_tambah_curicullum_vitae')); ?>" class="btn btn-primary">Tambah Data</a>
                    </div>
                    <div class="card-body">
                        <?php if(Session::has('status')): ?>
                            <?php if(Session::get('status') == 'berhasil'): ?>
                            <button class="btn btn-success mb-3"
                                style="width: 100%; border-radius: 10px; margin-bottom: 20px">Data Berhasil Dihapus</button>
                            <?php else: ?>
                            <button class="btn btn-danger mb-3"
                                style="width: 100%; border-radius: 10px; margin-bottom: 20px">Data Gagal Dihapus</button>
                            <?php endif; ?>
                        <?php endif; ?>
                            <table id="example" class="display">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Nama Penyetor</th>
                                        <th>Nama File</th>
                                        <th>Tanggal Kirim</th>
                                        <th>Keterangan</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($value->id_curriculum_vitae); ?></td>
                                            <td><?php echo e($value->nama_penyetor); ?></td>
                                            <td><?php echo e($value->nama_file); ?></td>
                                            <td><?php echo e($value->tanggal_upload); ?></td>
                                            <td><?php echo e($value->keterangan); ?></td>
                                            <td>
                                                <a href="<?php echo e(url('files/curicullum_vitae')); ?>/<?php echo e($value->nama_file); ?>" class="btn btn-info">Lihat</a>
                                                <a href="<?php echo e(route('edit_curicullum_vitae', ['id' => $value->id_curriculum_vitae])); ?>" class="btn btn-primary">Edit</a>
                                                <a href="<?php echo e(route('delete_curicullum_vitae', ['id' => $value->id_curriculum_vitae, 'file_name' => $value->nama_file])); ?>" class="btn btn-danger">Hapus</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--**********************************
    Content body end
***********************************-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PROJECT\Sistem Informasi Pengarsipan\resources\views/staff/curricullum-vitae.blade.php ENDPATH**/ ?>