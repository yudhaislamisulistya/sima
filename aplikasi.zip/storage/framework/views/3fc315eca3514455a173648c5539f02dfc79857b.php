<?php $__env->startSection('title', 'Staff Panel - Halaman Dashboard'); ?>


<?php $__env->startSection('content'); ?>
<div class="content-body">
    <div class="container-fluid">
        <div class="page-titles">
            <h4>Tambah Surat Masuk</h4>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0)">Tambah Surat Masuk</a></li>
            </ol>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Tambah Surat Masuk</h4>
                    </div>
                    <div class="card-body">
                        <?php if(Session::has('status')): ?>
                            <?php if(Session::get('status') == 'berhasil'): ?>
                            <button class="btn btn-success mb-3"
                                style="width: 100%; border-radius: 10px; margin-bottom: 20px">Data Berhasil Ditambahkan</button>
                            <?php else: ?>
                            <button class="btn btn-danger mb-3"
                                style="width: 100%; border-radius: 10px; margin-bottom: 20px">Data Gagal Ditambahkan</button>
                            <?php endif; ?>
                        <?php endif; ?>
                        <div class="basic-form">
                            <form action="<?php echo e(route('update_surat_masuk')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id_surat_masuk" value="<?php echo e($data->id_surat_masuk); ?>">
                                <div class="form-group">
                                    <label>Nomor Agenda</label>
                                    <input type="text" value="<?php echo e($data->no_agenda); ?>" name="no_agenda" class="form-control input-rounded" placeholder="001/AB/CDE/2020">
                                </div>
                                <div class="form-group">
                                    <label>Nomor Surat</label>
                                    <input type="text" value="<?php echo e($data->no_surat); ?>" name="no_surat" class="form-control input-rounded" placeholder="2939/LP/X/2020">
                                </div>
                                <div class="form-group">
                                    <label>Tanggal Surat</label>
                                    <input type="date" value="<?php echo e($data->tgl_surat); ?>" name="tgl_surat" class="form-control input-rounded" placeholder="2021-06-15">
                                </div>
                                <div class="form-group">
                                    <label>Tanggal Terima</label>
                                    <input type="date" value="<?php echo e($data->tgl_terima); ?>" name="tgl_terima" class="form-control input-rounded" placeholder="2021-06-15">
                                </div>
                                <div class="form-group">
                                    <label>Sumber Surat</label>
                                    <input type="text" value="<?php echo e($data->sumber_surat); ?>" name="sumber_surat" class="form-control input-rounded" placeholder="...">
                                </div>
                                <div class="form-group">
                                    <label>Perihal</label>
                                    <input type="text" value="<?php echo e($data->perihal); ?>" name="perihal" class="form-control input-rounded" placeholder="...">
                                </div>
                                <div class="form-group">
                                    <label>Keterangan</label>
                                    <textarea value="<?php echo e($data->keterangan); ?>" name="keterangan" class="form-control" placeholder="..." name="" id="" cols="30"
                                        rows="10"><?php echo e($data->keterangan); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label>File Surat</label>
                                    <input type="file" name="file_surat" class="form-control input-rounded" placeholder="...">
                                    <input type="hidden" name="file_surat_ada" value="<?php echo e($data->file_surat); ?>">
                                    <small>Lihat File <a href="<?php echo e(url('files/surat_masuk/')); ?>/<?php echo e($data->file_surat); ?>"><?php echo e($data->file_surat); ?></a></small>
                                </div>
                                <button type="submit" class="btn btn-primary">Proses</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--**********************************
    Content body end
***********************************-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PROJECT\Sistem Informasi Pengarsipan\resources\views/staff/edit/edit-surat-masuk.blade.php ENDPATH**/ ?>