<?php $__env->startSection('title', 'Staff Panel - Halaman Dashboard'); ?>


<?php $__env->startSection('content'); ?>
<div class="content-body">
    <div class="container-fluid">
        <div class="page-titles">
            <h4>Ubah Pegawai</h4>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                <li class="breadcrumb-item active"><a href="javascript:void(0)">Ubah Pegawai</a></li>
            </ol>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4 class="card-title">Ubah Pegawai</h4>
                    </div>
                    <div class="card-body">
                        <?php if(Session::has('status')): ?>
                            <?php if(Session::get('status') == 'berhasil'): ?>
                            <button class="btn btn-success mb-3"
                                style="width: 100%; border-radius: 10px; margin-bottom: 20px">Data Berhasil Diubah</button>
                            <?php else: ?>
                            <button class="btn btn-danger mb-3"
                                style="width: 100%; border-radius: 10px; margin-bottom: 20px">Data Gagal Diubah</button>
                            <?php endif; ?>
                        <?php endif; ?>
                        <div class="basic-form">
                            <form action="<?php echo e(route('update_pegawai')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id_data_pegawai" value="<?php echo e($data->id_data_pegawai); ?>">
                                <div class="form-group">
                                    <label>NIK</label>
                                    <input type="text" value="<?php echo e($data->nik); ?>" name="nik" class="form-control input-rounded" placeholder="7200......">
                                </div>
                                <div class="form-group">
                                    <label>NIP</label>
                                    <input type="text" value="<?php echo e($data->nip); ?>" name="nip" class="form-control input-rounded" placeholder="7200......">
                                </div>
                                <div class="form-group">
                                    <label>Nama</label>
                                    <input type="text" value="<?php echo e($data->nama); ?>" name="nama" class="form-control input-rounded" placeholder="Apriyadi Aries">
                                </div>
                                <div class="form-group">
                                    <label>Alamat</label>
                                    <input type="text" value="<?php echo e($data->alamat); ?>" name="alamat" class="form-control input-rounded" placeholder="Jl. Saddang">
                                </div>
                                <div class="form-group">
                                    <label>Jenis Kelamin</label>
                                    <select name="jenis_kelamin" class="form-control input-rounded">
                                        <option value="<?php echo e($data->jenis_kelamin); ?>"><?php echo e($data->jenis_kelamin); ?></option>
                                        <option value="" disabled>---------------</option>
                                        <option value="Laki-Laki">Laki-Laki</option>
                                        <option value="Perempuan">Perempuan</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Kontak</label>
                                    <input value="<?php echo e($data->kontak); ?>" type="text" name="kontak" class="form-control input-rounded" placeholder="085344020323">
                                </div>
                                <div class="form-group">
                                    <label>Jabatan</label>
                                    <select name="jabatan" class="form-control input-rounded">
                                        <option value="<?php echo e($data->jabatan); ?>"><?php echo e($data->jabatan); ?></option>
                                        <option value="" disabled>---------------</option>
                                        <?php $__currentLoopData = Helper::get_jabatan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value->nama_jabatan); ?>"><?php echo e($value->nama_jabatan); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Keterangan</label>
                                    <textarea value="<?php echo e($data->keterangan); ?>" type="text" name="keterangan" class="form-control" placeholder="..." name="" id="" cols="30"
                                        rows="10"><?php echo e($data->keterangan); ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label>Status</label>
                                    <select name="status" class="form-control input-rounded">
                                        <option value="<?php echo e($data->status); ?>"><?php echo e($data->status); ?></option>
                                        <option value="" disabled>---------------</option>
                                        <option value="Aktif">Aktif</option>
                                        <option value="Tidak Aktif">Tidak Aktif</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Tanggal Masuk</label>
                                    <input value="<?php echo e($data->tanggal_masuk); ?>" type="date" name="tanggal_masuk" class="form-control input-rounded" placeholder="2021-09-23">
                                </div>
                                <button type="submit" class="btn btn-primary">Proses</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--**********************************
    Content body end
***********************************-->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PROJECT\Sistem Informasi Pengarsipan\resources\views/staff/edit/edit-pegawai.blade.php ENDPATH**/ ?>